## writerifly

This is ai writer project using laravel, vue and Ant. Following below steps for the setup
